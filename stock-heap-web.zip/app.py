import os, time
from datetime import datetime, timezone
from heapq import heappush, heappushpop
from typing import List, Tuple
import pandas as pd
import yfinance as yf
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

DEFAULT_TICKERS = os.environ.get("TICKERS", "AAPL,MSFT,AMZN,GOOGL,META,NVDA,TSLA,AMD,NFLX,INTC").split(",")
CACHE_SECONDS = int(os.environ.get("CACHE_SECONDS", "60"))

_last_fetch = 0.0
_cached_closes = None
_cached_vols = None
_cached_meta = {}

def fetch_prices(tickers: List[str], period="1d", interval="5m"):
    data = yf.download(
        tickers=tickers, period=period, interval=interval,
        auto_adjust=True, progress=False, threads=True
    )
    if isinstance(data.columns, pd.MultiIndex):
        closes = data["Close"].copy()
        volumes = data["Volume"].copy()
    else:
        # single ticker case
        t = tickers[0]
        closes = data["Close"].to_frame(name=t)
        volumes = data["Volume"].to_frame(name=t)
    return closes.dropna(how="all"), volumes.dropna(how="all")

def ensure_data(tickers: List[str], period="1d", interval="5m"):
    global _last_fetch, _cached_closes, _cached_vols, _cached_meta
    now = time.time()
    tickers = [t.strip() for t in tickers if t.strip()]
    if not tickers:
        tickers = DEFAULT_TICKERS

    if (now - _last_fetch) > CACHE_SECONDS or _cached_closes is None:
        closes, vols = fetch_prices(tickers, period=period, interval=interval)
        _cached_closes, _cached_vols = closes, vols
        _cached_meta = {"tickers": tickers, "period": period, "interval": interval, "fetched_at": datetime.now(timezone.utc).isoformat()}
        _last_fetch = now
    return _cached_closes, _cached_vols

def top_n_by_percent_change(closes: pd.DataFrame, n: int=5):
    heap = []
    for t in closes.columns:
        s = closes[t].dropna()
        if len(s) < 2:
            continue
        change = (s.iloc[-1] - s.iloc[0]) / s.iloc[0] * 100.0
        item = (float(change), t)
        if len(heap) < n:
            heappush(heap, item)
        else:
            if item[0] > heap[0][0]:
                heappushpop(heap, item)
    out = sorted(heap, reverse=True)
    return [{"ticker": t, "value": round(v, 2)} for (v, t) in out]

def top_n_by_volume(vols: pd.DataFrame, n: int=5):
    heap = []
    for t in vols.columns:
        v = vols[t].dropna()
        if v.empty:
            continue
        total_vol = float(v.sum())
        item = (total_vol, t)
        if len(heap) < n:
            heappush(heap, item)
        else:
            if item[0] > heap[0][0]:
                heappushpop(heap, item)
    out = sorted(heap, reverse=True)
    return [{"ticker": t, "value": int(v)} for (v, t) in out]

@app.route("/")
def index():
    return render_template("index.html", default_tickers=",".join(DEFAULT_TICKERS))

@app.route("/api/top")
def api_top():
    metric = request.args.get("metric", "change").lower()
    n = int(request.args.get("n", "5"))
    tickers_param = request.args.get("tickers", "")
    tickers = [t.strip() for t in tickers_param.split(",") if t.strip()] or DEFAULT_TICKERS
    interval = request.args.get("interval", "5m")
    period = request.args.get("period", "1d")

    closes, vols = ensure_data(tickers, period=period, interval=interval)

    if metric == "volume":
        top = top_n_by_volume(vols, n=n)
        label = "total_volume"
    else:
        top = top_n_by_percent_change(closes, n=n)
        label = "pct_change"

    return jsonify({
        "metric": metric,
        "label": label,
        "top": top,
        "meta": {"tickers": tickers, "period": period, "interval": interval}
    })

@app.route("/api/series")
def api_series():
    ticker = request.args.get("ticker")
    if not ticker:
        return jsonify({"error": "ticker required"}), 400
    tickers_param = request.args.get("tickers", "")
    tickers = [t.strip() for t in tickers_param.split(",") if t.strip()] or DEFAULT_TICKERS
    interval = request.args.get("interval", "5m")
    period = request.args.get("period", "1d")

    closes, _ = ensure_data(tickers, period=period, interval=interval)
    if ticker not in closes.columns:
        return jsonify({"error": "ticker not in data"}), 404
    s = closes[ticker].dropna()
    series = [{"t": ts.isoformat(), "price": float(v)} for ts, v in zip(s.index, s.values)]
    return jsonify({"ticker": ticker, "series": series})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
